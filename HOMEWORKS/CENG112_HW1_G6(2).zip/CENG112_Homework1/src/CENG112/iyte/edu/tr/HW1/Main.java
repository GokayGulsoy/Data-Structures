package CENG112.iyte.edu.tr.HW1;

public class Main {
	public static void main(String[] args) {

		// Creating an object of Demo class
		Demo playListGenerator = new Demo();
		// Calling runApplication method 
		playListGenerator.runApplication();
		
	}

}

