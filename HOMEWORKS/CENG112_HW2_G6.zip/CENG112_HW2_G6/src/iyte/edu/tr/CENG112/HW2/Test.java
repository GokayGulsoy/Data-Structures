package iyte.edu.tr.CENG112.HW2;

public class Test {
	public static void main(String[] args) {
		
		// creating Demo class object 
		Demo demo = new Demo();
		demo.simulateFoodStore();				
		
	} // end Test

}
