package iyte.edu.tr.CENG112.HW3;

public class Main {
  public static void main(String[] args)
  {
	// creating an instance of ManagementSystem
	ManagementSystem manager = new ManagementSystem();
	
	// simulating patient management system
	manager.simulatePatientManagementSystem();
	
  }
}
